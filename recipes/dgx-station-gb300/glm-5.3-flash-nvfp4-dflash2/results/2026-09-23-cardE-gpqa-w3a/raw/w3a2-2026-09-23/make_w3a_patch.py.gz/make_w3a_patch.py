#!/usr/bin/env python3
"""make_w3a_patch.py STOCK_SRT_DIR OUT_DIR

W3a (2026-09-23, Milo for James): DFlash "fixed verify width" on SGLang v0.5.20-cu130.
The drafter still proposes its trained block (block_size = 7 tokens incl. anchor); the TARGET verifies only the
first K tokens (anchor + K-1 drafts). One axis: verify width. Env-gated: SGLANG_DFLASH_VERIFY_WIDTH=K (0/unset =
stock behaviour, byte-for-byte same code path).

Mechanism (mirrors EAGLE adaptive's SpecRuntimeState swap, minus the controller):
  * at init_cuda_graphs, build a second TARGET attention backend + target-verify CUDA graph runner under a
    scoped override speculative_num_draft_tokens=K (DSA / KDA backends cache the width at init);
  * per decode step (greedy, no grammar, no selector-sampling), slice tokens / positions / cache locs to [:, :K],
    swap the target runner's attn_backend + decode_cuda_graph_runner to the K runtime for verify + mamba commit,
    and make every downstream consumer K-wide (logits adjustments, accept, logprobs stride, draft-KV append,
    scheduler output stride via result.speculative_num_draft_tokens);
  * any other step falls back to the stock full-width path (counted).
Second file: DSA KPool asserts pool.tail_extra_slots == num_draft_tokens; the tail ring is sized from the max
width (7) and every reader/writer indexes it `% TAIL_SIZE` from the tensor shape, so a narrower verify is
in-bounds -> relax to `>=`.

Fail-closed: every replacement anchor must match exactly once.
"""
import hashlib, os, sys

SRC, OUT = sys.argv[1], sys.argv[2]
TAG = "# PATCHED (jmeadlock W3a.2 verify-width incl. grammar steps 2026-09-23)"


def sub(text, old, new, name):
    n = text.count(old)
    if n != 1:
        sys.exit(f"ANCHOR_FAIL {name}: found {n} matches")
    return text.replace(old, new)


# ------------------------------------------------------------------ dflash_worker_v2.py
p = os.path.join(SRC, "speculative/dflash_worker_v2.py")
s = open(p).read()
stock_sha = hashlib.sha256(s.encode()).hexdigest()

s = sub(s, "import logging\nimport math\n", f"{TAG}\nimport logging\nimport math\n", "header")

s = sub(s,
"from sglang.srt.model_executor.cuda_graph_config import Backend\n",
"from sglang.srt.model_executor.cuda_graph_config import (\n    Backend,\n    Phase,\n    check_cuda_graph_backend,\n)\n",
"imp_cuda_graph_config")

s = sub(s,
"from sglang.srt.runtime_context import (\n    get_exec,\n",
"from sglang.srt.runtime_context import (\n    get_context,\n    get_exec,\n",
"imp_runtime_context")

s = sub(s,
"from sglang.srt.utils.common import empty_context\n",
"from sglang.srt.utils.common import empty_context, get_available_gpu_memory\n",
"imp_utils")

# __init__: env + state
s = sub(s,
"        self._out_tokens_bufs: List[torch.Tensor] = []\n        self._new_seq_lens_bufs: List[torch.Tensor] = []\n",
"        self._out_tokens_bufs: List[torch.Tensor] = []\n        self._new_seq_lens_bufs: List[torch.Tensor] = []\n"
"        # W3a verify-width: target verifies only the first K block positions.\n"
"        self._vw = int(os.environ.get(\"SGLANG_DFLASH_VERIFY_WIDTH\", \"0\") or 0)\n"
"        if self._vw and not (2 <= self._vw < int(self.block_size)):\n"
"            raise ValueError(\n"
"                f\"SGLANG_DFLASH_VERIFY_WIDTH={self._vw} must satisfy 2 <= K < block_size={self.block_size}\"\n"
"            )\n"
"        self._vw_runtime = None  # (target_attn_backend, target_graph_runner) built at init_cuda_graphs\n"
"        self._vw_out_bufs: dict = {}\n"
"        self._vw_slot = 0\n"
"        self._vw_steps = 0\n"
"        self._vw_fallback_steps = 0\n"
"        self._vw_why: dict = {}\n",
"init_state")

# init_cuda_graphs: build the K runtime after the draft graphs (outside the draft tp context)
s = sub(s,
"            self._draft_worker.init_cuda_graphs(\n                capture_decode_cuda_graph=capture_decode_cuda_graph\n            )\n",
"            self._draft_worker.init_cuda_graphs(\n                capture_decode_cuda_graph=capture_decode_cuda_graph\n            )\n"
"        if self._vw:\n"
"            self._build_verify_width_runtime(int(self._vw))\n"
"\n"
"    def _build_verify_width_runtime(self, width: int) -> None:\n"
"        \"\"\"W3a: a second target attn backend + verify graph runner at `width` tokens/req.\"\"\"\n"
"        if get_parallel().enable_dp_attention:\n"
"            raise ValueError(\"SGLANG_DFLASH_VERIFY_WIDTH is not supported with dp attention\")\n"
"        from sglang.srt.model_executor.runner import DecodeCudaGraphRunner\n"
"\n"
"        tmr = self._target_worker.model_runner\n"
"        before = get_available_gpu_memory(self.device, self.gpu_id)\n"
"        full = int(self.block_size)\n"
"        get_context().override(\n"
"            \"dflash_verify_width.capture_override\", speculative_num_draft_tokens=width\n"
"        )\n"
"        try:\n"
"            backup_init = tmr.init_new_workspace\n"
"            try:\n"
"                attn_backend = tmr._get_attention_backend(init_new_workspace=True)\n"
"            finally:\n"
"                tmr.init_new_workspace = backup_init\n"
"            # Mirror ModelRunner.init_attention_backends: every reachable backend carries THIS translator.\n"
"            tmr.kv_index_translator.bind_and_verify_backends([attn_backend])\n"
"            graph_runner = None\n"
"            if not check_cuda_graph_backend(Phase.DECODE, Backend.DISABLED):\n"
"                graph_runner = DecodeCudaGraphRunner(\n"
"                    tmr,\n"
"                    attn_backend=attn_backend,\n"
"                    speculative_num_steps=get_spec().speculative_num_steps,\n"
"                    speculative_num_draft_tokens=width,\n"
"                )\n"
"        finally:\n"
"            get_context().override(\n"
"                \"dflash_verify_width.capture_restore\", speculative_num_draft_tokens=full\n"
"            )\n"
"        if int(get_spec().speculative_num_draft_tokens) != full:\n"
"            raise RuntimeError(\"DFLASH verify-width: failed to restore speculative_num_draft_tokens\")\n"
"        self._vw_runtime = (attn_backend, graph_runner)\n"
"        after = get_available_gpu_memory(self.device, self.gpu_id)\n"
"        if self.ps.tp_rank == 0:\n"
"            logger.info(\n"
"                \"DFLASH verify-width runtime built: draft block=%d, target verify width=%d, graph=%s, mem=%.2f GB\",\n"
"                full,\n"
"                width,\n"
"                graph_runner is not None,\n"
"                before - after,\n"
"            )\n"
"\n"
"    def _vw_out_tokens_buf(self, bs: int, width: int) -> torch.Tensor:\n"
"        bufs = self._vw_out_bufs.get(width)\n"
"        if bufs is None or bufs[0].shape[0] < bs:\n"
"            cap = max(int(bs), 2 * bufs[0].shape[0] if bufs is not None else int(bs))\n"
"            bufs = [\n"
"                torch.empty((cap, width), dtype=torch.int64, device=self.device)\n"
"                for _ in range(2)\n"
"            ]\n"
"            self._vw_out_bufs[width] = bufs\n"
"        slot = self._vw_slot\n"
"        self._vw_slot = (slot + 1) % 2\n"
"        return bufs[slot][:bs]\n",
"init_cuda_graphs")

# _accept_block: width-aware
s = sub(s,
"        prefix_lens: torch.Tensor,\n        bs: int,\n    ):\n        new_seq_lens = None\n",
"        prefix_lens: torch.Tensor,\n        bs: int,\n        width: Optional[int] = None,\n    ):\n        width = int(self.block_size) if width is None else int(width)\n        new_seq_lens = None\n",
"accept_sig")
s = sub(s,
"            target_predict = torch.argmax(next_token_logits, dim=-1).view(\n                bs, int(self.block_size)\n            )\n",
"            target_predict = torch.argmax(next_token_logits, dim=-1).view(bs, width)\n",
"accept_view")
s = sub(s,
"                    ) = self._next_accept_bonus_buffers(bs)\n",
"                    ) = self._next_accept_bonus_buffers(bs)\n"
"                    if width != int(self.block_size):\n"
"                        out_tokens = self._vw_out_tokens_buf(bs, width)\n",
"accept_bufs")

# forward: choose width after the draft block is materialized
s = sub(s,
"        draft_tokens = self._draft_block_tokens_buf[:bs]\n        draft_tokens[:, 0].copy_(block_ids[:, 0])\n        draft_tokens[:, 1:].copy_(draft_next)\n",
"        draft_tokens = self._draft_block_tokens_buf[:bs]\n        draft_tokens[:, 0].copy_(block_ids[:, 0])\n        draft_tokens[:, 1:].copy_(draft_next)\n"
"\n"
"        # W3a.2 verify-width: greedy, non-selector-sampling steps verify only [:, :vw]; grammar steps too\n"
"        # (the grammar bitmask is built over the same K-wide chain below).\n"
"        vw = block_size\n"
"        if self._vw_runtime is not None:\n"
"            if (\n"
"                _is_all_greedy(batch.sampling_info)\n"
"                and self._selector_sample is None\n"
"            ):\n"
"                vw = int(self._vw)\n"
"                self._vw_steps += 1\n"
"                if batch.has_grammar:\n"
"                    self._vw_why[\"narrow_grammar\"] = self._vw_why.get(\"narrow_grammar\", 0) + 1\n"
"            else:\n"
"                self._vw_fallback_steps += 1\n"
"                _si = batch.sampling_info\n"
"                _why = (\n"
"                    \"nongreedy\" if not _is_all_greedy(_si)\n"
"                    else \"selector_sample\"\n"
"                )\n"
"                self._vw_why[_why] = self._vw_why.get(_why, 0) + 1\n"
"                if self._vw_why[_why] <= 2 and self.ps.tp_rank == 0:\n"
"                    logger.info(\n"
"                        \"DFLASH verify-width fallback: why=%s has_grammar=%s si_none=%s is_all_greedy=%s selector_sample_none=%s selector=%s sel_sampling=%s\",\n"
"                        _why, batch.has_grammar, _si is None,\n"
"                        None if _si is None else _si.is_all_greedy,\n"
"                        self._selector_sample is None, self.selector is not None,\n"
"                        getattr(self, \"_selector_sampling_enabled\", None),\n"
"                    )\n"
"            if (self._vw_steps + self._vw_fallback_steps) % 256 == 1 and self.ps.tp_rank == 0:\n"
"                logger.info(\n"
"                    \"DFLASH verify-width stats: width=%d steps=%d fallback_full_width=%d why=%s\",\n"
"                    int(self._vw),\n"
"                    self._vw_steps,\n"
"                    self._vw_fallback_steps,\n"
"                    dict(self._vw_why),\n"
"                )\n"
"        if vw != block_size:\n"
"            v_tokens = draft_tokens[:, :vw].contiguous()\n"
"            v_positions = positions_2d[:, :vw].reshape(-1)\n"
"            v_cache_loc_2d = verify_out_cache_loc_2d[:, :vw].contiguous()\n"
"            v_cache_loc = v_cache_loc_2d.reshape(-1)\n"
"        else:\n"
"            v_tokens = draft_tokens\n"
"            v_positions = positions\n"
"            v_cache_loc_2d = verify_out_cache_loc_2d\n"
"            v_cache_loc = verify_out_cache_loc\n",
"choose_width")

# W3a.2: the grammar bitmask chain must be the verified K-wide chain (mask rows == logits rows).
s = sub(s,
"            GrammarTree.from_linear_chain(draft_tokens) if batch.has_grammar else None\n",
"            GrammarTree.from_linear_chain(v_tokens) if batch.has_grammar else None\n",
"grammar_tree_width")

s = sub(s,
"        verify_input_ids = draft_tokens.reshape(-1)\n        verify_input = DFlashVerifyInput(\n            draft_token=verify_input_ids,\n            positions=positions,\n            draft_token_num=int(self.block_size),\n",
"        verify_input_ids = v_tokens.reshape(-1)\n        verify_input = DFlashVerifyInput(\n            draft_token=verify_input_ids,\n            positions=v_positions,\n            draft_token_num=int(vw),\n",
"verify_input")

s = sub(s,
"        batch.out_cache_loc = verify_out_cache_loc\n        sampling_info = batch.sampling_info\n",
"        batch.out_cache_loc = v_cache_loc\n        sampling_info = batch.sampling_info\n",
"out_cache_loc")

s = sub(s,
"            verify_host_seq_lens = seq_lens_cpu_backup + block_size\n",
"            verify_host_seq_lens = seq_lens_cpu_backup + vw\n",
"host_seq_lens")

s = sub(s,
"        verify_forward_batch, _ = verify_input.prepare_for_verify(\n            batch, self.target_worker\n        )\n",
"        _vw_saved = None\n"
"        if vw != block_size:\n"
"            _tmr = self.target_worker.model_runner\n"
"            _vw_saved = (_tmr.attn_backend, _tmr.decode_cuda_graph_runner)\n"
"            _tmr.attn_backend, _tmr.decode_cuda_graph_runner = self._vw_runtime\n"
"        verify_forward_batch, _ = verify_input.prepare_for_verify(\n            batch, self.target_worker\n        )\n",
"swap_in")

s = sub(s,
"                sampling_info=sampling_info,\n                draft_token_num=int(self.block_size),\n            )\n",
"                sampling_info=sampling_info,\n                draft_token_num=int(vw),\n            )\n",
"logits_adj")

s = sub(s,
"        candidates = draft_tokens\n",
"        candidates = v_tokens\n",
"candidates")

s = sub(s,
"            draft_input=draft_input,\n            prefix_lens=prefix_lens,\n            bs=bs,\n        )\n",
"            draft_input=draft_input,\n            prefix_lens=prefix_lens,\n            bs=bs,\n            width=vw,\n        )\n",
"accept_call")

s = sub(s,
"                target_predict = torch.argmax(\n                    logits_output.next_token_logits, dim=-1\n                ).view(bs, int(self.block_size))\n",
"                target_predict = torch.argmax(\n                    logits_output.next_token_logits, dim=-1\n                ).view(bs, int(vw))\n",
"simulate_view")

s = sub(s,
"                out_tokens.reshape(-1),\n                chain_stride=block_size,\n",
"                out_tokens.reshape(-1),\n                chain_stride=vw,\n",
"logprob_stride")

s = sub(s,
"        if new_seq_lens is None:\n            new_seq_lens = prefix_lens + commit_lens.to(prefix_lens.dtype)\n        if on_publish is not None:\n            on_publish(new_seq_lens)\n",
"        if _vw_saved is not None:\n"
"            _tmr = self.target_worker.model_runner\n"
"            _tmr.attn_backend, _tmr.decode_cuda_graph_runner = _vw_saved\n"
"        if new_seq_lens is None:\n            new_seq_lens = prefix_lens + commit_lens.to(prefix_lens.dtype)\n        if on_publish is not None:\n            on_publish(new_seq_lens)\n",
"swap_out")

s = sub(s,
"        hidden = hidden.view(bs, int(self.block_size), -1)\n\n        self._append_target_hidden_to_draft_kv_by_loc(\n            target_hidden=hidden.reshape(-1, hidden.shape[-1]),\n            cache_loc=verify_out_cache_loc,\n            cache_loc_2d=verify_out_cache_loc_2d,\n            positions=positions,\n",
"        hidden = hidden.view(bs, int(vw), -1)\n\n        self._append_target_hidden_to_draft_kv_by_loc(\n            target_hidden=hidden.reshape(-1, hidden.shape[-1]),\n            cache_loc=v_cache_loc,\n            cache_loc_2d=v_cache_loc_2d,\n            positions=v_positions,\n",
"kv_append")

s = sub(s,
"            next_draft_input=next_draft_input,\n            speculative_num_draft_tokens=int(self.block_size),\n            # The non-overlap",
"            next_draft_input=next_draft_input,\n            speculative_num_draft_tokens=int(vw),\n            # The non-overlap",
"result_width")

os.makedirs(os.path.join(OUT, "speculative"), exist_ok=True)
open(os.path.join(OUT, "speculative/dflash_worker_v2.py"), "w").write(s)

# ------------------------------------------------------------------ kpool_plan.py
p2 = os.path.join(SRC, "layers/attention/dsa/kpool_plan.py")
k = open(p2).read()
stock_sha2 = hashlib.sha256(k.encode()).hexdigest()
k = sub(k,
"        assert pool.tail_extra_slots == num_draft_tokens, (\n",
f"        {TAG}: tail ring sized for the max width; a narrower verify is in-bounds.\n"
"        assert pool.tail_extra_slots >= num_draft_tokens, (\n",
"kpool_assert")
os.makedirs(os.path.join(OUT, "layers/attention/dsa"), exist_ok=True)
open(os.path.join(OUT, "layers/attention/dsa/kpool_plan.py"), "w").write(k)

for rel in ("speculative/dflash_worker_v2.py", "layers/attention/dsa/kpool_plan.py"):
    b = open(os.path.join(OUT, rel), "rb").read()
    print(f"{hashlib.sha256(b).hexdigest()}  {rel}")
print(f"stock {stock_sha}  speculative/dflash_worker_v2.py")
print(f"stock {stock_sha2}  layers/attention/dsa/kpool_plan.py")
